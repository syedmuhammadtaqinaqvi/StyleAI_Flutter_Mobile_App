import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';
import '../providers/wardrobe_provider.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final weather = Provider.of<WeatherProvider>(context);
    final wardrobe = Provider.of<WardrobeProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome, ${Provider.of(context, listen: false).currentUser}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Provider.of(context, listen: false).logOut();
              Navigator.of(context).pushReplacementNamed('/auth');
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Current Weather', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 16),
              _buildWeatherCard(weather),
              const SizedBox(height: 32),
              Text('My Wardrobe', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 16),
              _buildWardrobeGrid(wardrobe),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWeatherCard(WeatherProvider weather) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (weather.isLoading)
              const Center(
                child: CircularProgressIndicator(),
              )
            else ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(weather.location, style: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.bold)),
                  IconButton(
                    icon: const Icon(Icons.refresh),
                    onPressed: weather.getWeatherData,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Text('${weather.temperature}', style: GoogleFonts.playfairDisplay(fontSize: 48, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(weather.condition, style: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.w500)),
                      Text('Suggestions: ${weather.getWeatherSuggestions().join(', ')}',
                          style: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w300)),
                    ],
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildWardrobeGrid(WardrobeProvider wardrobe) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: wardrobe.items.length,
      gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 3/2, crossAxisSpacing: 10, mainAxisSpacing: 10),
      itemBuilder: (ctx, i) {
        final item = wardrobe.items[i];
        return GridTile(
          child: Image.asset(item.imagePath, fit: BoxFit.cover),
          footer: GridTileBar(
            backgroundColor: Colors.black87,
            title: Text(item.name, textAlign: TextAlign.center),
          ),
        );
      },
    );
  }
}
