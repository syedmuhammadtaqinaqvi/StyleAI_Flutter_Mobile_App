import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';
import '../providers/wardrobe_provider.dart';

class RecommendationsScreen extends StatefulWidget {
  const RecommendationsScreen({Key? key}) : super(key: key);

  @override
  State<RecommendationsScreen> createState() => _RecommendationsScreenState();
}

class _RecommendationsScreenState extends State<RecommendationsScreen> {
  String _selectedOccasion = '';
  String _selectedTimeOfDay = 'morning';
  bool _isGenerating = false;
  List<Map<String, dynamic>> _recommendations = [];

  final List<String> _occasions = [
    'work',
    'casual',
    'formal',
    'party',
    'date',
    'gym',
    'travel',
  ];

  final List<String> _timesOfDay = [
    'morning',
    'afternoon',
    'evening',
    'night',
  ];

  @override
  Widget build(BuildContext context) {
    final weather = Provider.of<WeatherProvider>(context);
    final wardrobe = Provider.of<WardrobeProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Style Recommendations'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Smart Style Recommendations',
              style: GoogleFonts.playfairDisplay(
                fontSize: 24,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Tell us about your occasion and let AI curate the perfect outfit',
              style: GoogleFonts.inter(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),

            // Occasion Selection
            Text(
              'Occasion',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _selectedOccasion.isEmpty ? null : _selectedOccasion,
              hint: const Text('Select Occasion'),
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
              ),
              items: _occasions.map((occasion) {
                return DropdownMenuItem(
                  value: occasion,
                  child: Text(occasion.toUpperCase()),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedOccasion = value ?? '';
                });
              },
            ),
            
            const SizedBox(height: 16),

            // Time of Day Selection
            Text(
              'Time of Day',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _selectedTimeOfDay,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
              ),
              items: _timesOfDay.map((time) {
                return DropdownMenuItem(
                  value: time,
                  child: Text(time.toUpperCase()),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedTimeOfDay = value ?? 'morning';
                });
              },
            ),

            const SizedBox(height: 24),

            // Weather info
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.wb_sunny,
                    color: Colors.white,
                    size: 32,
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${weather.temperature} - ${weather.condition}',
                        style: GoogleFonts.inter(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        weather.location,
                        style: GoogleFonts.inter(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Generate button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _selectedOccasion.isEmpty || _isGenerating
                    ? null
                    : () => _generateRecommendations(weather, wardrobe),
                child: _isGenerating
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      )
                    : const Text('Generate Style Recommendations'),
              ),
            ),

            const SizedBox(height: 24),

            // Recommendations
            if (_recommendations.isNotEmpty) ...[
              Text(
                'Your Personalized Outfit Recommendations',
                style: GoogleFonts.playfairDisplay(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView.builder(
                  itemCount: _recommendations.length,
                  itemBuilder: (context, index) {
                    final recommendation = _recommendations[index];
                    return _buildRecommendationCard(recommendation);
                  },
                ),
              ),
            ] else if (!_isGenerating) ...[
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.auto_awesome,
                        size: 64,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No recommendations yet',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          color: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Select an occasion and generate recommendations!',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          color: Colors.grey[500],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildRecommendationCard(Map<String, dynamic> recommendation) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              recommendation['title'],
              style: GoogleFonts.playfairDisplay(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 8),
            
            // Outfit items
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: (recommendation['items'] as List<String>)
                  .map((item) => Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          item,
                          style: GoogleFonts.inter(
                            fontSize: 12,
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ))
                  .toList(),
            ),
            
            const SizedBox(height: 12),
            
            Text(
              recommendation['description'],
              style: GoogleFonts.inter(
                fontSize: 14,
                color: Colors.grey[700],
              ),
            ),
            
            const SizedBox(height: 12),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Confidence: ${recommendation['confidence']}%',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.green,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.favorite_border),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('${recommendation['title']} saved to favorites!'),
                      ),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _generateRecommendations(WeatherProvider weather, WardrobeProvider wardrobe) async {
    setState(() {
      _isGenerating = true;
    });

    // Simulate AI processing
    await Future.delayed(const Duration(seconds: 2));

    final recommendations = _createRecommendations();
    
    setState(() {
      _recommendations = recommendations;
      _isGenerating = false;
    });
  }

  List<Map<String, dynamic>> _createRecommendations() {
    final titles = {
      'work': ['Professional Power Look', 'Business Casual Chic', 'Executive Style'],
      'casual': ['Weekend Vibes', 'Casual Cool', 'Relaxed Elegance'],
      'formal': ['Black Tie Elegance', 'Formal Sophistication', 'Evening Glamour'],
      'party': ['Party Ready', 'Night Out Look', 'Social Butterfly'],
      'date': ['Date Night Magic', 'Romantic Charm', 'Dinner Date Style'],
      'gym': ['Workout Ready', 'Fitness Fashion', 'Active Style'],
      'travel': ['Travel Comfort', 'Airport Chic', 'Journey Style'],
    };

    final items = {
      'work': ['Blazer', 'Dress Shirt', 'Trousers', 'Dress Shoes', 'Watch'],
      'casual': ['T-Shirt', 'Jeans', 'Sneakers', 'Sunglasses', 'Casual Jacket'],
      'formal': ['Suit Jacket', 'Dress Shirt', 'Dress Pants', 'Formal Shoes', 'Tie'],
      'party': ['Statement Top', 'Dark Jeans', 'Heels', 'Statement Jewelry', 'Clutch'],
      'date': ['Nice Blouse', 'Skirt', 'Heels', 'Cardigan', 'Accessories'],
      'gym': ['Athletic Top', 'Leggings', 'Sneakers', 'Sports Bra', 'Water Bottle'],
      'travel': ['Comfortable Top', 'Comfortable Pants', 'Walking Shoes', 'Light Jacket', 'Backpack'],
    };

    final descriptions = {
      'work': 'Perfect for making a professional impression while staying comfortable throughout your workday.',
      'casual': 'Effortlessly stylish for your everyday activities and weekend adventures.',
      'formal': 'Elegant and sophisticated for special occasions and formal events.',
      'party': 'Stand out from the crowd with this fun and fashionable party outfit.',
      'date': 'Romantic and charming, perfect for creating lasting memories.',
      'gym': 'Functional and fashionable activewear for your fitness routine.',
      'travel': 'Comfortable and practical while maintaining your style on the go.',
    };

    return List.generate(3, (index) {
      return {
        'title': titles[_selectedOccasion]?[index] ?? 'Stylish Look',
        'items': items[_selectedOccasion] ?? items['casual']!,
        'description': descriptions[_selectedOccasion] ?? 'A versatile and stylish outfit choice.',
        'confidence': 80 + (index * 5),
      };
    });
  }
}
