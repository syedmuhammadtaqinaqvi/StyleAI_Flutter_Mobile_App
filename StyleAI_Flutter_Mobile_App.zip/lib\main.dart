import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'screens/splash_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/wardrobe_screen.dart';
import 'screens/recommendations_screen.dart';
import 'providers/app_state.dart';
import 'providers/weather_provider.dart';
import 'providers/wardrobe_provider.dart';

void main() {
  runApp(const StyleAIApp());
}

class StyleAIApp extends StatelessWidget {
  const StyleAIApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState()),
        ChangeNotifierProvider(create: (_) => WeatherProvider()),
        ChangeNotifierProvider(create: (_) => WardrobeProvider()),
      ],
      child: MaterialApp(
        title: 'StyleAI - Fashion Assistant',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
          primaryColor: const Color(0xFF667EEA),
          colorScheme: const ColorScheme.light(
            primary: Color(0xFF667EEA),
            secondary: Color(0xFF764BA2),
            surface: Colors.white,
            background: Color(0xFFF5F7FA),
          ),
          textTheme: GoogleFonts.interTextTheme(
            Theme.of(context).textTheme,
          ).copyWith(
            headlineLarge: GoogleFonts.playfairDisplay(
              fontSize: 32,
              fontWeight: FontWeight.bold,
              color: const Color(0xFF333333),
            ),
            headlineMedium: GoogleFonts.playfairDisplay(
              fontSize: 24,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF333333),
            ),
          ),
          appBarTheme: AppBarTheme(
            backgroundColor: Colors.white.withOpacity(0.95),
            elevation: 8,
            shadowColor: Colors.black.withOpacity(0.1),
            titleTextStyle: GoogleFonts.playfairDisplay(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF333333),
            ),
            iconTheme: const IconThemeData(color: Color(0xFF333333)),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667EEA),
              foregroundColor: Colors.white,
              elevation: 8,
              shadowColor: const Color(0xFF667EEA).withOpacity(0.3),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFE0E6ED), width: 2),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF667EEA), width: 2),
            ),
            filled: true,
            fillColor: const Color(0xFFF8F9FF),
            contentPadding: const EdgeInsets.all(16),
          ),
        ),
        home: const SplashScreen(),
        routes: {
          '/auth': (context) => const AuthScreen(),
          '/home': (context) => const HomeScreen(),
          '/wardrobe': (context) => const WardrobeScreen(),
          '/recommendations': (context) => const RecommendationsScreen(),
        },
      ),
    );
  }
}
