import 'package:flutter/material.dart';
import 'dart:io';

class WardrobeItem {
  final String id;
  final String name;
  final String type;
  final String color;
  final String imagePath;
  final DateTime uploadDate;

  WardrobeItem({
    required this.id,
    required this.name,
    required this.type,
    required this.color,
    required this.imagePath,
    required this.uploadDate,
  });
}

class WardrobeProvider extends ChangeNotifier {
  final List<WardrobeItem> _items = [];

  List<WardrobeItem> get items => _items;

  void addItem(WardrobeItem item) {
    _items.add(item);
    notifyListeners();
  }

  void removeItem(String id) {
    _items.removeWhere((item) => item.id == id);
    notifyListeners();
  }

  List<WardrobeItem> getItemsByType(String type) {
    return _items.where((item) => item.type == type).toList();
  }

  WardrobeItem? getItemById(String id) {
    try {
      return _items.firstWhere((item) => item.id == id);
    } catch (e) {
      return null;
    }
  }

  void loadSampleItems() {
    _items.clear();
    _items.addAll([
      WardrobeItem(
        id: '1',
        name: 'White Button Shirt',
        type: 'top',
        color: 'White',
        imagePath: 'assets/images/sample_shirt.jpg',
        uploadDate: DateTime.now(),
      ),
      WardrobeItem(
        id: '2',
        name: 'Dark Jeans',
        type: 'bottom',
        color: 'Blue',
        imagePath: 'assets/images/sample_jeans.jpg',
        uploadDate: DateTime.now(),
      ),
      WardrobeItem(
        id: '3',
        name: 'Navy Blazer',
        type: 'outerwear',
        color: 'Navy',
        imagePath: 'assets/images/sample_blazer.jpg',
        uploadDate: DateTime.now(),
      ),
    ]);
    notifyListeners();
  }

  String detectClothingType(String filename) {
    final name = filename.toLowerCase();
    if (name.contains('shirt') || name.contains('top')) return 'top';
    if (name.contains('pants') || name.contains('jeans')) return 'bottom';
    if (name.contains('dress')) return 'dress';
    if (name.contains('jacket') || name.contains('coat')) return 'outerwear';
    if (name.contains('shoe')) return 'shoes';
    return 'accessory';
  }

  String generateClothingName() {
    final types = ['Shirt', 'Dress', 'Pants', 'Jacket', 'Skirt', 'Blouse', 'Sweater', 'Jeans'];
    return types[DateTime.now().millisecond % types.length];
  }

  String generateColor() {
    final colors = ['Red', 'Blue', 'Green', 'Black', 'White', 'Navy', 'Beige', 'Brown', 'Gray', 'Pink'];
    return colors[DateTime.now().millisecond % colors.length];
  }
}
