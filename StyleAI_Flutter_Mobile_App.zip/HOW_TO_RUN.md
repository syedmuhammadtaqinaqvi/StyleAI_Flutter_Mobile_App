# How to Run StyleAI Flutter App on Your Phone

## Prerequisites

### 1. Install Flutter
- Download Flutter SDK from: https://flutter.dev/docs/get-started/install
- Extract it to a folder (e.g., `C:\flutter`)
- Add Flutter to your PATH environment variable
- Run `flutter doctor` to verify installation

### 2. Enable Developer Options on Your Phone
1. Go to **Settings** → **About Phone**
2. Tap **Build Number** 7 times
3. Go back to **Settings** → **Developer Options**
4. Enable **USB Debugging**
5. Enable **Install via USB**

### 3. Install Android SDK (if not already installed)
- Android Studio will automatically install this
- Or download command line tools from: https://developer.android.com/studio

## Quick Setup (Automatic)

1. Connect your phone to your computer via USB
2. Navigate to `D:\styleai_flutter_app`
3. Double-click `setup_and_run.bat`
4. Follow the on-screen instructions

## Manual Setup

### Step 1: Connect Your Device
```bash
# Connect your phone via USB cable
# Allow USB debugging when prompted on your phone
```

### Step 2: Navigate to Project
```bash
cd D:\styleai_flutter_app
```

### Step 3: Get Dependencies
```bash
flutter pub get
```

### Step 4: Check Connected Devices
```bash
flutter devices
```
You should see your phone listed here.

### Step 5: Run the App
```bash
# Run on your connected phone
flutter run

# Or run in Chrome browser for testing
flutter run -d chrome

# Or build APK file to install manually
flutter build apk --release
```

## Troubleshooting

### Phone Not Detected
- Make sure USB debugging is enabled
- Try different USB cable
- Install phone drivers if needed
- Use `adb devices` to check if phone is detected

### Flutter Not Found
- Make sure Flutter is added to PATH
- Restart command prompt/terminal
- Run `flutter doctor` to diagnose issues

### Build Errors
- Run `flutter clean` then `flutter pub get`
- Make sure you have the latest Flutter version
- Check that all dependencies are compatible

## App Features

Once the app is running on your phone, you can:

1. **Splash Screen**: See the beautiful "Created by Taqi Naqvi" splash screen
2. **Authentication**: Sign up or log in to your account
3. **Weather Integration**: Get real-time weather for outfit recommendations
4. **Wardrobe Management**: Upload photos of your clothes
5. **AI Recommendations**: Get personalized outfit suggestions
6. **Location Services**: Allow location access for weather data

## Building APK for Distribution

To create an APK file you can share:

```bash
flutter build apk --release
```

The APK will be created at:
`D:\styleai_flutter_app\build\app\outputs\flutter-apk\app-release.apk`

## API Configuration

Don't forget to replace `'your-api-key-here'` in the following files with actual API keys:

1. `lib/providers/weather_provider.dart` - OpenWeatherMap API key
2. `lib/script.js` (web version) - Same API key

Get your free API key from: https://openweathermap.org/api

## Contact

Created by **Taqi Naqvi**
- This is your final year project
- Fashion Technology Innovator

---

**StyleAI - Where Fashion Meets Technology** 💫
