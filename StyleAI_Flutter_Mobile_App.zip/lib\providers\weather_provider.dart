import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class WeatherProvider extends ChangeNotifier {
  String _temperature = '22°C';
  String _condition = 'Sunny';
  String _location = 'Your Location';
  bool _isLoading = false;

  String get temperature => _temperature;
  String get condition => _condition;
  String get location => _location;
  bool get isLoading => _isLoading;

  Future<void> getWeatherData() async {
    _isLoading = true;
    notifyListeners();

    try {
      // Get location permission
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.deniedForever) {
        // Use default weather
        _setDefaultWeather();
        return;
      }

      // Get current position
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      // Fetch weather data
      await _fetchWeatherByCoords(position.latitude, position.longitude);
    } catch (e) {
      print('Weather error: $e');
      _setDefaultWeather();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _fetchWeatherByCoords(double lat, double lon) async {
    const apiKey = 'your-api-key-here'; // Replace with actual API key
    final url = 'https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric';

    try {
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        _temperature = '${data['main']['temp'].round()}°C';
        _condition = data['weather'][0]['main'];
        _location = '${data['name']}, ${data['sys']['country']}';
      } else {
        _setDefaultWeather();
      }
    } catch (e) {
      print('API error: $e');
      _setDefaultWeather();
    }
  }

  void _setDefaultWeather() {
    _temperature = '22°C';
    _condition = 'Sunny';
    _location = 'Your Location';
  }

  List<String> getWeatherSuggestions() {
    switch (_condition.toLowerCase()) {
      case 'sunny':
      case 'clear':
        return [
          'Light cotton fabrics recommended',
          "Don't forget sunglasses",
          'Perfect weather for bright colors'
        ];
      case 'rain':
      case 'drizzle':
        return [
          'Waterproof jacket essential',
          'Closed-toe shoes recommended',
          'Darker colors to hide stains'
        ];
      case 'clouds':
        return [
          'Perfect for layering',
          'Light jacket might be useful',
          'Great weather for any color'
        ];
      case 'snow':
        return [
          'Heavy coat and warm layers',
          'Waterproof boots necessary',
          'Add gloves and scarves'
        ];
      default:
        return [
          'Check the weather before heading out',
          'Layer clothing for comfort',
          'Choose versatile pieces'
        ];
    }
  }
}
