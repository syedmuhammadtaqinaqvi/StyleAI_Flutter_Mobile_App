import 'package:flutter/material.dart';

class AppState extends ChangeNotifier {
  String _currentUser = '';
  bool _isLoggedIn = false;

  String get currentUser => _currentUser;
  bool get isLoggedIn => _isLoggedIn;

  void logIn(String user) {
    _currentUser = user;
    _isLoggedIn = true;
    notifyListeners();
  }

  void logOut() {
    _currentUser = '';
    _isLoggedIn = false;
    notifyListeners();
  }
}
